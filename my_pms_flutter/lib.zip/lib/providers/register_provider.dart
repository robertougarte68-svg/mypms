import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class User {
  String? name;
  String? user;
  String? email;
  String? pass;
  String? pass2;

  User();

  Map<String, dynamic> toJson() => {
    "name": name,
    "email": email,
    "username": user,
    "password": pass,
  };
}

class RegisterProvider extends ChangeNotifier {
  final nwUser = User();
  final _formKey = GlobalKey<FormState>();
  final ip = '192.168.100.66';
  GlobalKey<FormState> get formKey => _formKey;
  bool passValidation() => nwUser.pass != null && nwUser.pass == nwUser.pass2;

  //registrar nuevo usuario
  Future<bool> sendUser() async {
    final url = Uri.parse("http://$ip:3000/database/users/registerUser");
    final head = {"Content-Type": "application/json"};
    final bodi = jsonEncode(nwUser.toJson());
    try {
      final response = await http
          .post(url, headers: head, body: bodi)
          .timeout(Duration(seconds: 2));
      if (response.statusCode <= 301) {
        print(jsonDecode(response.body));
        return true;
      } else {
        print('error de servidor ${response.statusCode}');
        print('${jsonDecode(response.body)}');
        // return false;
      }
      // print(response);
    } on http.ClientException catch (e) {
      print('error de cliente $e');
    } on TimeoutException catch (_) {
      print('Tiempo de espera agotado');
    } catch (e) {
      print('Error inesperado: $e');
    }
    return false;
  }
}
