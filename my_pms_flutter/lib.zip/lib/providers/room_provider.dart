import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Room {
  final int id;
  final int number;
  final String name;
  final String state;

  Room({
    required this.id,
    required this.number,
    required this.name,
    required this.state,
  });

  factory Room.fromJson(Map<String, dynamic> json) {
    return Room(
      id: json['id'],
      number: json['number'],
      name: json['name'],
      state: json['state'],
    );
  }
}

class RoomProvider extends ChangeNotifier {
  String ip = '192.168.100.66';
  List<Room> _rooms = [];
  bool _loading = false;

  List<Room> get rooms => _rooms;
  bool get loading => _loading;

  void refresh() {
    notifyListeners();
  }

  //This metod search for a room to give it
  Future<void> fetchRooms() async {
    _loading = true;
    // notifyListeners();
    print("empezando fetchRooms en provider");
    final response = await http.get(
      Uri.parse('http://$ip:3000/database/rooms'),
    );

    if (response.statusCode >= 200 && response.statusCode < 300) {
      List jsonData = json.decode(response.body);
      _rooms = jsonData.map((e) => Room.fromJson(e)).toList();
      print(_rooms);
    } else {
      print(
        "respuesta fuera de 200 en fetchRooms en provider ${response.statusCode}",
      );
      throw response.statusCode;
    }

    _loading = false;
  }

  //This metod add a new room to the DB
  Future<void> postRoom(Map<String, dynamic> room) async {
    // _loading = true;
    final response = await http.post(
      Uri.parse('http://$ip:3000/database/rooms'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(room),
    );

    if (response.statusCode == 200 || response.statusCode == 201) {
      print("se ha ejecutado postRoom");
    } else {
      throw response.statusCode;
    }
    // _loading = false;
  }

  //This metod change the state of the room
  Future<void> patchRoom(Map<String, dynamic> room, int id) async {
    final response = await http.patch(
      Uri.parse('http://$ip:3000/database/rooms/$id'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(room),
    );
    if (response.statusCode == 200 || response.statusCode == 201) {
      notifyListeners();
    } else {
      throw response.statusCode;
    }
  }

  //This metod deletes a room in the db
  Future<void> deleteRoom(int id) async {
    final response = await http.delete(
      Uri.parse('http://$ip:3000/database/rooms/$id'),
    );
    if (199 < response.statusCode && response.statusCode < 300) {
      notifyListeners();
    } else {
      throw response.statusCode;
    }
  }
}
