import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Client {
  final int id;
  final String name;
  final int edad;
  final int ci;

  Client({
    required this.id,
    required this.name,
    required this.edad,
    required this.ci,
  });

  String get getName => name;
  int get getId => id;
  int get getEdad => edad;
  int get getCi => ci;
  factory Client.fromJson(Map<String, dynamic> json) {
    return Client(
      id: json['id'],
      name: json['name'],
      edad: json['edad'] ?? 18,
      ci: json['ci'] ?? 9430657,
    );
  }
}

class ClientProvider extends ChangeNotifier {
  String ip = "192.168.100.66";
  List<Client> _clients = [];
  List<dynamic> similars = [];
  Client specificClient = Client(id: 0, name: "", edad: 0, ci: 0);
  bool _loading = false;

  List<Client> get clients => _clients;
  bool get loading => _loading;

  //Solicita similares a la DB
  Future<void> searchSimilars(String similar) async {
    final response = await http.get(
      Uri.parse('http://$ip:3000/database/clientes/search?query=$similar'),
    );

    if (response.statusCode == 200) {
      similars = json.decode(response.body);
    } else {
      print(response.statusCode);
      // throw response.statusCode;
    }
    notifyListeners();
  }

  //Solicita CLIENTE ESPECIFICO a la DB
  Future<void> getClient(int id) async {
    final response = await http.get(
      Uri.parse('http://${ip}:3000/database/clientes/$id'),
    );

    if (response.statusCode == 200) {
      specificClient = Client.fromJson(json.decode(response.body)[0]);
    } else {
      throw response.statusCode;
    }
    notifyListeners();
  }

  //solicita todos los usuarios a la DB
  Future<void> fetchClients() async {
    _loading = true;
    notifyListeners();

    final response = await http.get(
      Uri.parse('http://${ip}:3000/database/clientes'),
    );

    if (response.statusCode == 200) {
      List jsonData = json.decode(response.body);
      _clients = jsonData.map((e) => Client.fromJson(e)).toList();
    } else {
      throw response.statusCode;
    }

    _loading = false;
    notifyListeners();
  }

  // solicita clientes por fecha
  Future<void> clientsByDate(String date) async {
    _loading = true;
    notifyListeners();

    final response = await http.get(
      Uri.parse('http://${ip}:3000/database/clientes/bydate?date=$date'),
    );

    if (response.statusCode >= 200 || response.statusCode < 300) {
      List jsonData = json.decode(response.body);
      print(jsonData);
      _clients = jsonData.map((e) => Client.fromJson(e)).toList();
    } else {
      throw response.statusCode;
    }

    _loading = false;
    notifyListeners();
  }

  //guarda un nuevo cliente en la DB
  Future<void> writeClient(Map<String, dynamic> client) async {
    final response = await http.post(
      Uri.parse('http://${ip}:3000/database/clientes'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(client),
    );

    if (response.statusCode == 200 || response.statusCode == 201) {
      notifyListeners();
    } else {
      throw response.statusCode;
    }
  }
}
