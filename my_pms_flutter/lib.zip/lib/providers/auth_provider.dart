import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AuthProvider extends ChangeNotifier {
  bool _loggedIn = false;
  String? _userEmail;

  final _emailControl = TextEditingController();
  final _passControl = TextEditingController();

  bool get loggedIn => _loggedIn;
  String? get userEmail => _userEmail;
  TextEditingController get emailControl => _emailControl;
  TextEditingController get passControl => _passControl;

  String ip = "192.168.100.66";

  Future<bool> login(String email, String password) async {
    // Aquí llamas al backend o validas localmente
    final url = Uri.parse("http://$ip:3000/database/users/login");
    final head = {"Content-Type": "application/json"};
    final bodi = jsonEncode({"email": email, "password": password});
    try {
      final response = await http
          .post(url, headers: head, body: bodi)
          .timeout(Duration(seconds: 2));
      if (response.statusCode <= 301) {
        print(jsonDecode(response.body));
        notifyListeners();
        return true;
      } else {
        print('error de servidor ${response.statusCode}');
        print('${jsonDecode(response.body)}');
        // return false;
      }
      // print(response);
    } on http.ClientException catch (e) {
      print('error de cliente $e');
    } on TimeoutException catch (_) {
      print('Tiempo de espera agotado');
    } catch (e) {
      print('Error inesperado: $e');
    }
    return false;
  }

  void logout() {
    _loggedIn = false;
    _userEmail = null;
    notifyListeners();
  }
}
