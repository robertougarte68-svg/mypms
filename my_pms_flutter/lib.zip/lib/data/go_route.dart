import 'package:go_router/go_router.dart';
import 'package:my_pms/presentation/auth/create_hotel_screen.dart';
import 'package:my_pms/presentation/auth/join_hotel_screen.dart';
import 'package:my_pms/presentation/auth/login_screen.dart';
import 'package:my_pms/presentation/auth/register_screen.dart';
import 'package:my_pms/presentation/screens/homepage.dart';

final GoRouter router = GoRouter(
  initialLocation: '/register',
  routes: [
    GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
    GoRoute(
      path: '/register',
      builder: (context, state) => const RegisterScreen(),
    ),
    GoRoute(
      path: '/create',
      builder: (context, state) => const CreateHotelScreen(),
    ),
    GoRoute(
      path: '/join',
      builder: (context, state) => const JoinHotelScreen(),
    ),
    GoRoute(
      path: '/dashboard',
      builder: (context, state) => const MyHomePage(),
    ),
    GoRoute(
      path: '/check',
      builder: (context, state) {
        // Lógica de redirección
        // if (!LocalDB.user['isLogged']) return const LoginScreen();
        // if (LocalDB.user['hotelId'] == null)
        //   return const CreateHotelScreen(); // o JoinHotelScreen

        return const MyHomePage(); //TODO
      },
    ),
  ],
);
