import 'package:flutter/material.dart';

class JoinHotelScreen extends StatelessWidget {
  const JoinHotelScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
