import 'package:flutter/material.dart';

class CreateHotelScreen extends StatelessWidget {
  const CreateHotelScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
