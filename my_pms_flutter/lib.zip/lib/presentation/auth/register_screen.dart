import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:my_pms/providers/register_provider.dart';
import 'package:provider/provider.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final regProv = context.watch<RegisterProvider>();
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Color(0xFF1C1C1C)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 30),
              padding: const EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: Colors.grey.shade900.withOpacity(0.95),
                borderRadius: BorderRadius.circular(25),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black87,
                    blurRadius: 15,
                    offset: Offset(0, 8),
                  ),
                ],
                border: Border.all(color: Colors.amber, width: 2),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "Crear Cuenta",
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: Colors.amber,
                    ),
                  ),
                  const SizedBox(height: 30),
                  Form(
                    key: regProv.formKey,
                    child: Column(
                      children: [
                        _buildInput(
                          "Nombre Completo",
                          Icons.person,
                          (value) => regProv.nwUser.name = value,
                        ),
                        const SizedBox(height: 20),

                        _buildInput(
                          "Correo Electrónico",
                          Icons.email,
                          (value) => regProv.nwUser.email = value,
                        ),
                        const SizedBox(height: 20),

                        _buildInput(
                          "Usuario",
                          Icons.account_circle,
                          (value) => regProv.nwUser.user = value,
                        ),
                        const SizedBox(height: 20),

                        _buildInput(
                          "Contraseña",
                          Icons.lock,
                          (value) => regProv.nwUser.pass = value,
                          isPassword: true,
                        ),
                        const SizedBox(height: 20),

                        _buildInput(
                          "Confirmar Contraseña",
                          Icons.lock_outline,
                          (value) => regProv.nwUser.pass2 = value,
                          isPassword: true,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),

                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        elevation: 8,
                      ),
                      onPressed: () async {
                        if (regProv.formKey.currentState!.validate()) {
                          regProv.formKey.currentState!.save();
                          // Ejecuta todos los onSaved

                          if (!regProv.passValidation())
                            print("contrasenas no coinciden");
                          else {
                            if (await regProv.sendUser()) {
                              regProv.formKey.currentState!.reset();
                              GoRouter.of(context).go('/login');
                            }
                          }
                        }
                      },
                      child: const Text(
                        "Registrarse",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  TextButton(
                    onPressed: () {
                      GoRouter.of(context).go('/login');
                    },
                    child: Text(
                      "¿Ya tienes cuenta? Inicia sesión",
                      style: TextStyle(
                        color: Colors.amber.shade400,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInput(
    String hint,
    IconData icon,
    Function(String? value) saved, {
    bool isPassword = false,
  }) {
    return TextFormField(
      onSaved: saved,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return "Campo obligatorio";
        }
        return null;
      },
      obscureText: isPassword,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.grey.shade500),
        prefixIcon: Icon(icon, color: Colors.amber),
        filled: true,
        fillColor: Colors.grey.shade800,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
