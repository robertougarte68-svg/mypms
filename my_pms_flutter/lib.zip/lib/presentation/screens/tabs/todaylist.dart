import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:my_pms/providers/client_provider.dart';
import 'package:provider/provider.dart';

class TodayList extends StatelessWidget {
  const TodayList({super.key});

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<ClientProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 150),
          child: ElevatedButton(
            // style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
            onPressed: () async {
              final DateTime? picked = await showDatePicker(
                context: context,
                initialDate: DateTime.now(), // Fecha inicial
                firstDate: DateTime(1990), // Fecha mínima
                lastDate: DateTime(2050), // Fecha máxima
              );
              if (picked != null) {
                final formatted =
                    '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';

                userProvider.clientsByDate(formatted);
              }
            },
            child: Row(
              children: [
                Text(
                  '${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
                ),
                Icon(Icons.calendar_today),
              ],
            ),
          ),
        ),
      ),
      body: Container(
        // padding: EdgeInsets.all(1),
        child: DataTable2(
          columnSpacing: 5,
          horizontalMargin: 30,
          minWidth: 500,
          columns: [
            DataColumn2(label: Text("ID"), size: ColumnSize.S),
            DataColumn2(label: Text("name")),
            DataColumn2(label: Text("edad")),
            DataColumn2(label: Text("ci")),
            DataColumn2(label: Text("despachar")),
          ],
          rows: userProvider.clients.map((e) {
            return DataRow2(
              cells: [
                DataCell(Text('${e.id}')),
                DataCell(Text(e.name)),
                DataCell(Text('${e.edad}')),
                DataCell(Text('${e.ci}')),
                DataCell(
                  ElevatedButton(child: Text("out"), onPressed: () => {}),
                ),
              ],
            );
          }).toList(),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.refresh),
        onPressed: () {},
      ),
    );
  }
}
