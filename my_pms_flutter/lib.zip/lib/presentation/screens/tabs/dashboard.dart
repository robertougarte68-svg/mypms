import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:my_pms/providers/room_provider.dart';

class MyDashboard extends StatelessWidget {
  const MyDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final nsRoom = context.watch<RoomProvider>();
    final stateColors = {
      'libre': Colors.green,
      'ocupado': Colors.red,
      'mantenimiento': Colors.orange,
      'revision': Colors.yellow,
    };

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Rooms State:',
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ),
      body: FutureBuilder(
        future: nsRoom.fetchRooms(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final roomsData = nsRoom.rooms;
          return Padding(
            padding: const EdgeInsets.all(20),
            child: GridView.count(
              crossAxisCount: 3,
              mainAxisSpacing: 20,
              crossAxisSpacing: 20,
              children: roomsData.map((room) {
                return ElevatedButton(
                  onPressed: () => _showModalBottomSheet(context, nsRoom, room),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: stateColors[room.state] ?? Colors.grey,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        room.number.toString(),
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(room.name, style: const TextStyle(fontSize: 20)),
                      Text(room.state, style: const TextStyle(fontSize: 16)),
                    ],
                  ),
                );
              }).toList(),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final atributos = await Navigator.pushNamed(context, "/newroom");
          if (atributos != null && atributos is Map<String, dynamic>) {
            await nsRoom.postRoom(atributos);
            nsRoom.refresh();
            print("hola mundo despues de refresh");
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showModalBottomSheet(
    BuildContext context,
    RoomProvider nsRoom,
    Room room,
  ) {
    showModalBottomSheet(
      context: context,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildStateTile(context, nsRoom, room, 'ocupado', Colors.red),
          _buildStateTile(context, nsRoom, room, 'libre', Colors.green),
          _buildStateTile(context, nsRoom, room, 'revision', Colors.yellow),
          ListTile(
            leading: const Icon(Icons.delete, color: Colors.white),
            title: const Text('Eliminar'),
            onTap: () {
              nsRoom.deleteRoom(room.id);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  ListTile _buildStateTile(
    BuildContext context,
    RoomProvider nsRoom,
    Room room,
    String state,
    Color color,
  ) {
    return ListTile(
      leading: Icon(Icons.circle, color: color),
      title: Text(state[0].toUpperCase() + state.substring(1)),
      onTap: () {
        nsRoom.patchRoom({'state': state}, room.id);
        Navigator.pop(context);
      },
    );
  }
}
