import 'package:flutter/material.dart';
import 'package:my_pms/providers/client_provider.dart';
import 'package:provider/provider.dart';

class MyRegister extends StatelessWidget {
  const MyRegister({super.key});

  @override
  Widget build(BuildContext context) {
    final nombreControl = TextEditingController();
    final edadControl = TextEditingController();
    final ciControl = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final searchControl = TextEditingController();
    final nsUser = context.read<ClientProvider>();
    Map<String, dynamic> formFields = {
      'name': 'default',
      'edad': 18,
      'ci': 9430657,
    };

    return Scaffold(
      appBar: AppBar(
        // title: ConstrainedBox(
        //   constraints: BoxConstraints(maxWidth: 300),
        //   child: TextField(
        //     decoration: InputDecoration(icon: Icon(Icons.search_rounded)),
        //   ),
        // ),
      ),
      body: Container(
        margin: EdgeInsets.only(top: 30),
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              //campo de busqueda:
              TextField(
                controller: searchControl,
                decoration: InputDecoration(icon: Icon(Icons.search_rounded)),
                onChanged: (value) {
                  print("buscando: $value");
                  nsUser.searchSimilars(value);
                },
              ),
              //lista de sugerencias
              Consumer<ClientProvider>(
                builder: (_, provider, _) {
                  if (provider.similars.isNotEmpty) {
                    return ListView.builder(
                      shrinkWrap: true,
                      // physics: const NeverScrollableScrollPhysics(),
                      itemCount: provider.similars.length,
                      itemBuilder: (context, index) {
                        final client = provider.similars[index];
                        return ListTile(
                          title: Text(client["name"]),
                          onTap: () async {
                            await provider.getClient(client["id"]);
                            nombreControl.text = provider.specificClient.name;
                            edadControl.text =
                                '${provider.specificClient.edad}';
                            ciControl.text = '${provider.specificClient.ci}';
                          },
                        );
                      },
                    );
                  } else {
                    return const SizedBox.shrink();
                  }
                },
              ),

              SizedBox(height: 20),
              Form(
                key: formKey,
                child: Column(
                  children: [
                    //campo nombre
                    TextFormField(
                      controller: nombreControl,
                      decoration: const InputDecoration(labelText: 'Nombre'),
                      // initialValue: nsUser.specificClient.getName,
                      onSaved: (value) {
                        formFields['name'] = value;
                      },
                      validator: (value) {
                        if (value == null ||
                            value.isEmpty ||
                            int.tryParse(value) != null) {
                          return 'Nombre-Obligatorio';
                        }
                        return null;
                      },
                    ),
                    //campo edad
                    TextFormField(
                      controller: edadControl,
                      decoration: const InputDecoration(labelText: 'Edad'),
                      // initialValue: '${nsUser.specificClient.getEdad}',
                      onSaved: (value) {
                        formFields['edad'] = int.tryParse(value!);
                      },
                      validator: (value) {
                        if (value == null ||
                            value.isEmpty ||
                            int.tryParse(value) == null) {
                          return 'Edad-Obligatorio';
                        }
                        return null;
                      },
                    ),
                    //campo ci
                    TextFormField(
                      controller: ciControl,
                      decoration: const InputDecoration(labelText: 'CI'),
                      // initialValue: '${nsUser.specificClient.getCi}',
                      onSaved: (value) {
                        formFields['ci'] = int.tryParse(value!);
                      },
                      validator: (value) {
                        if (value == null ||
                            value.isEmpty ||
                            int.tryParse(value) == null) {
                          return 'CI-Obligatorio';
                        }
                        return null;
                      },
                    ),
                    //boton de envio
                    ElevatedButton(
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          formKey.currentState!.save();
                          // Ejecuta todos los onSaved
                          formKey.currentState!.reset();
                          searchControl.clear();
                          nsUser.writeClient(formFields);
                          nsUser.similars.clear();
                        }
                      },
                      child: Text("Registrar"),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
