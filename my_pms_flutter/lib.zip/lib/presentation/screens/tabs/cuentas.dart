import 'package:flutter/material.dart';

class Cuentas extends StatefulWidget {
  const Cuentas({super.key});

  @override
  State<Cuentas> createState() => _CuentasState();
}

class _CuentasState extends State<Cuentas> {
  int index = 0;
  List<Map<String, int>> infoBoxes = [
    {
      "Saldo ayer": 100,
      "Egresos hoy": 20,
      "Retiros hoy": 200,
      "Ingresos hoy": 50,
      "Saldo hoy": 482,
    },
    {
      "Saldo inicial mes": 100,
      "Egresos mes": 20,
      "Retiros mes": 200,
      "Ingresos mes": 10,
      "Saldo mes": 482,
    },
    {
      "Saldo inicial ano": 100,
      "Egresos ano": 20,
      "Retiros ano": 200,
      "Ingresos ano": 50,
      "Saldo ano": 402,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          spacing: 10,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                setState(() {
                  index = 0;
                });
              },
              child: Text("today"),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  index = 1;
                });
              },
              child: Text("month"),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  index = 2;
                });
              },
              child: Text("year"),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(50),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: 200),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(30),
              child: Column(
                spacing: 10,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: infoBoxes[index].entries
                    .map(
                      (e) => Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: Text(
                              '${e.key}:      ',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Expanded(flex: 1, child: Text('${e.value}')),
                        ],
                      ),
                    )
                    .toList(),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
