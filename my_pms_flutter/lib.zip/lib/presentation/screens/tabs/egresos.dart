import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';

class Egresos extends StatelessWidget {
  const Egresos({super.key});

  DataRow usern(int id, String name, int ci, TimeOfDay hour) {
    return DataRow(
      cells: [
        DataCell(Text(id.toString())),
        DataCell(Text(name)),
        DataCell(Text(ci.toString())),
        DataCell(Text('${hour.hour}:${hour.minute}')),
        DataCell(ElevatedButton(onPressed: () {}, child: Text("Editar"))),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 150),
          child: ElevatedButton(
            // style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
            onPressed: () {},
            child: Row(
              children: [
                Text(
                  '${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
                ),
                Icon(Icons.calendar_today),
              ],
            ),
          ),
        ),
      ),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: DataTable2(
              columnSpacing: 5,
              horizontalMargin: 10,
              minWidth: 400,
              columns: [
                DataColumn2(label: Text("ID"), size: ColumnSize.S),
                DataColumn2(label: Text("Detalle")),
                DataColumn2(label: Text("Egreso")),
                DataColumn2(label: Text("Hora")),
                DataColumn2(label: Text("Editar")),
              ],
              rows: [
                usern(1, "taxi", 10, TimeOfDay(hour: 10, minute: 20)),
                usern(2, "ceramica", 130, TimeOfDay(hour: 5, minute: 20)),
                usern(3, "ace", 200, TimeOfDay(hour: 6, minute: 10)),
                usern(4, "beto", 250, TimeOfDay(hour: 22, minute: 20)),
              ],
            ),
          ),
          SizedBox(
            // color: const Color.fromARGB(255, 142, 142, 142),
            width: 150,
            height: 100,
            child: Column(
              children: [
                ElevatedButton(onPressed: () {}, child: Text("Nuevo Egr")),
                ElevatedButton(onPressed: () {}, child: Text("Retirar")),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
