import 'package:flutter/material.dart';

// void main() => runApp(const MyApp());

class Pruebas extends StatelessWidget {
  const Pruebas({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: const Text('Selector de Fecha')),
        body: const Center(child: DatePickerButton()),
      ),
    );
  }
}

class DatePickerButton extends StatefulWidget {
  const DatePickerButton({super.key});

  @override
  State<DatePickerButton> createState() => _DatePickerButtonState();
}

class _DatePickerButtonState extends State<DatePickerButton> {
  DateTime? selectedDate;

  // Función para mostrar el DatePicker
  Future<void> _pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(), // Fecha inicial
      firstDate: DateTime(1990), // Fecha mínima
      lastDate: DateTime(2050), // Fecha máxima
    );

    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });

      // Aquí puedes realizar la acción que quieras con la fecha seleccionada
      // Por ejemplo, imprimirla en consola
      print('Fecha seleccionada: $selectedDate');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ElevatedButton(onPressed: _pickDate, child: Icon(Icons.date_range)),
        const SizedBox(height: 20),
        if (selectedDate != null)
          Text(
            'Fecha seleccionada: ${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}',
            style: const TextStyle(fontSize: 16),
          ),
      ],
    );
  }
}
