
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: ClientSearchPage());
  }
}

class ClientSearchPage extends StatefulWidget {
  const ClientSearchPage({super.key});

  @override
  State<ClientSearchPage> createState() => _ClientSearchPageState();
}



class _ClientSearchPageState extends State<ClientSearchPage> {
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  List<Map<String, String>> suggestions = []; // Datos simulados

  // Simulación de búsqueda
  void _search(String query) {
    final allClients = [
      {'id': '1', 'name': 'Roberto', 'email': 'roberto@email.com'},
      {'id': '2', 'name': 'Maria', 'email': 'maria@email.com'},
      {'id': '3', 'name': 'Juan', 'email': 'juan@email.com'},
    ];

    setState(() {
      suggestions = allClients
          .where((c) => c['name']!.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  // Simulación de autocompletar formulario
  void _selectClient(Map<String, String> client) {
    _nameController.text = client['name']!;
    _emailController.text = client['email']!;
    setState(() {
      suggestions = [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buscar Cliente')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: const InputDecoration(labelText: 'Buscar nombre'),
              onChanged: _search,
            ),
            // Sugerencias
            if (suggestions.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: suggestions.length,
                  itemBuilder: (context, index) {
                    final client = suggestions[index];
                    return ListTile(
                      title: Text(client['name']!),
                      onTap: () => _selectClient(client),
                    );
                  },
                ),
              ),
            const SizedBox(height: 20),
            // Formulario autocompletado
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Nombre'),
            ),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
          ],
        ),
      ),
    );
  }
}

