import 'package:flutter/material.dart';

class NewRoom extends StatefulWidget {
  const NewRoom({super.key});

  @override
  State<NewRoom> createState() => _NewRoomState();
}

class _NewRoomState extends State<NewRoom> {
  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> formFields = {
      'number': "1",
      'name': 'simple',
      'price': 50,
      'features': 'con tv',
    };

    final formKey = GlobalKey<FormState>();
    return Scaffold(
      appBar: AppBar(title: Text("Nueva Habitacion")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: 'Numero'),
                onSaved: (value) {
                  formFields['number'] = int.tryParse(value!);
                },
                validator: (value) {
                  if (value == null ||
                      value.isEmpty ||
                      int.tryParse(value) == null) {
                    return 'numero obligatorio';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Nombre'),
                onSaved: (value) {
                  formFields['name'] = value;
                },
                validator: (value) {
                  if (value == null ||
                      value.isEmpty ||
                      int.tryParse(value) != null) {
                    return 'literal obligatorio';
                  }
                  return null;
                },
              ),
              TextFormField(
                maxLines: 4,
                decoration: const InputDecoration(labelText: 'Descripcion'),
                onSaved: (value) {
                  formFields['features'] = value;
                },
                validator: (value) {
                  if (value == null ||
                      value.isEmpty ||
                      int.tryParse(value) != null) {
                    return 'literal obligatorio';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Precio'),
                onSaved: (value) {
                  formFields['price'] = int.tryParse(value!);
                },
                validator: (value) {
                  if (value == null ||
                      value.isEmpty ||
                      int.tryParse(value) == null) {
                    return 'valor obligatorio';
                  }
                  return null;
                },
              ),

              ElevatedButton(
                onPressed: () {
                  if (formKey.currentState!.validate()) {
                    formKey.currentState!.save(); // Ejecuta todos los onSaved
                    Navigator.pop(context, formFields);
                  }
                },
                child: Text("Crear nueva habitacion"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
