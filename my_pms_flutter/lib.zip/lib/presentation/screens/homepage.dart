import 'package:flutter/material.dart';
import 'package:my_pms/presentation/screens/tabs/cuentas.dart';
import 'package:my_pms/presentation/screens/tabs/dashboard.dart';
import 'package:my_pms/presentation/screens/tabs/egresos.dart';
import 'package:my_pms/presentation/screens/tabs/register.dart';
import 'package:my_pms/presentation/screens/tabs/todaylist.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          // leading: IconButton(onPressed: () {}, icon: Icon(Icons.menu)),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(child: Image.asset('assets/logotuku.jpg', height: 40)),
            ],
          ),
          bottom: const TabBar(
            tabs: [
              Tab(text: "Dashboard"),
              Tab(text: "Register"),
              Tab(text: "TodayList"),
              Tab(text: "Egresos"),
              Tab(text: "Cuentas"),
            ],
          ),
        ),
        drawer: Drawer(
          backgroundColor: const Color.fromARGB(255, 105, 105, 105),
          child: SizedBox(
            height: 200,
            width: 100,
            child: Column(children: [Text("data"), Text("data"), Text("data")]),
          ),
        ),
        body: TabBarView(
          children: [
            Center(child: MyDashboard()),
            Center(child: MyRegister()),
            Center(child: TodayList()),
            Center(child: Egresos()),
            Center(child: Cuentas()),
          ],
        ),
      ),
    );
  }
}

class FormFields {
  int? number;
  String? descripcion;
  int? precio;
}
