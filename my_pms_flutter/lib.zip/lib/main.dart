import 'package:flutter/material.dart';
import 'package:my_pms/data/go_route.dart'; //router
import 'package:my_pms/providers/auth_provider.dart';
import 'package:my_pms/providers/register_provider.dart';

//PROVIDERS
import 'package:provider/provider.dart';
import 'package:my_pms/providers/room_provider.dart';
import 'package:my_pms/providers/client_provider.dart';

void main() {
  // runApp(const Pruebas());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ClientProvider()),
        ChangeNotifierProvider(create: (_) => RoomProvider()),
        ChangeNotifierProvider(create: (_) => RegisterProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
      ],
      child: MaterialApp.router(
        routerConfig: router,
        title: 'pms_hotelero',
        theme: ThemeData(
          colorScheme: ColorScheme.dark(
            primary: const Color.fromARGB(255, 223, 175, 0),
            onPrimary: const Color.fromARGB(255, 0, 0, 0),
            secondary: const Color.fromARGB(255, 255, 244, 194),
            surface: Color.fromARGB(255, 34, 34, 34),
            tertiary: const Color.fromARGB(255, 47, 255, 0),
          ),

          useMaterial3: false,
        ),
        //home: DynamicButtonsPage(),
      ),
    );
  }
}
